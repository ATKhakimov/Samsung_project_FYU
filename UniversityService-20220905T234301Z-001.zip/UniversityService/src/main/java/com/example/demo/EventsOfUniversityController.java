package com.example.demo;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/events", produces = "application/json")
public class EventsOfUniversityController {
	private final ServiceDB dbService;
    
    @Autowired
    public EventsOfUniversityController(ServiceDB dbService) {
        this.dbService = dbService;
    }

    @GetMapping(value = "/{id:\\d+}")
    public ArrayList<Event> getCategory(@PathVariable int id) {
        return dbService.getEventsOfUniversity(id);
    }
}