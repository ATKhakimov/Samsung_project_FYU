package com.example.demo;

public class Event {
    int id;
    String name;
    int dateInSec;
    String date;

    public Event(int id, String name, int dateInSec, String date) {
        this.id = id;
        this.name = name;
        this.dateInSec = dateInSec;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDateInSec() {
        return dateInSec;
    }

    public void setDateInSec(int dateInSec) {
        this.dateInSec = dateInSec;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
