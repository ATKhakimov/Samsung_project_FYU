package com.example.demo;

public class FacultyWithUniversityName {
	int id;
    String name;
    int minSum;
    int point_math;
    int point_inf;
    int point_fiz;
    int point_rus;
    String universityName;

    public FacultyWithUniversityName(int id, String name, int minSum, int point_math, int point_inf, int point_fiz, int point_rus, String universityName) {
        this.id = id;
        this.name = name;
        this.minSum = minSum;
        this.point_math = point_math;
        this.point_inf = point_inf;
        this.point_fiz = point_fiz;
        this.point_rus = point_rus;
        this.universityName = universityName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMinSum() {
        return minSum;
    }

    public void setMinSum(int minSum) {
        this.minSum = minSum;
    }

    public int getPoint_math() {
        return point_math;
    }

    public void setPoint_math(int point_math) {
        this.point_math = point_math;
    }

    public int getPoint_inf() {
        return point_inf;
    }

    public void setPoint_inf(int point_inf) {
        this.point_inf = point_inf;
    }

    public int getPoint_fiz() {
        return point_fiz;
    }

    public void setPoint_fiz(int point_fiz) {
        this.point_fiz = point_fiz;
    }

    public int getPoint_rus() {
        return point_rus;
    }

    public void setPoint_rus(int point_rus) {
        this.point_rus = point_rus;
    }

	public String getUniversityName() {
		return universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}

}
