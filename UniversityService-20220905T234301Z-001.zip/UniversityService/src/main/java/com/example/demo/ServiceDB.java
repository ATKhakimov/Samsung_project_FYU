package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class ServiceDB {
	public Connection connect() {
		String url = "jdbc:sqlite:C:/Users/lyunk/eclipse-workspace/UniversityService/my.db"; //поменять на свой url
        Connection con = null;
        try {
            con = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return con;
    }
	
	public ArrayList<University> getAllUniversities(){
		String sql = "SELECT * FROM 'universities';";
		ArrayList<University> list = new ArrayList<>();
		try {
			Connection con = this.connect();
			PreparedStatement pstmt  = con.prepareStatement(sql);
			ResultSet rs  = pstmt.executeQuery();
			while (rs.next())  {
				list.add(new University(rs.getInt("id"), rs.getString("address"), rs.getString("name"), rs.getInt("place"), rs.getString("information")));
			}
			con.close();
			return list;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	public ArrayList<FacultyWithUniversityName> getFacultiesByPoints(String points){
		String sql = "SELECT faculties.id as id, universities.name as uname, faculties.name as name, minsum, math, inf, fiz, rus FROM 'universities', 'faculties'\r\n" + 
				"where faculties.universityid = universities.id and minsum <= ? and math <=? and inf <=? and rus <=? and fiz<=?;";
		String[] items = {points.substring(0, 3), points.substring(3, 6), points.substring(6,9), points.substring(9,12), points.substring(13)} ;

		int[] results = new int[items.length];

		for (int i = 0; i < items.length; i++) {
		    try {
		        results[i] = Integer.parseInt(items[i]);
		    } catch (NumberFormatException nfe) {
		        return null;
		    };
		}
		try {
			Connection con = this.connect();
			PreparedStatement pstmt  = con.prepareStatement(sql);
			pstmt.setInt(1, results[0]);
			pstmt.setInt(2, results[1]);
			pstmt.setInt(3, results[2]);
			pstmt.setInt(4, results[3]);
			pstmt.setInt(5, results[4]);
			ResultSet rs  = pstmt.executeQuery();
			ArrayList<FacultyWithUniversityName> faculties = new ArrayList<>();
			while (rs.next())  {
				faculties.add(new FacultyWithUniversityName(rs.getInt("id"), rs.getString("name"), rs.getInt("minsum"), rs.getInt("math"), rs.getInt("inf"), rs.getInt("fiz"), rs.getInt("rus"), rs.getString("uname")));
			}
			return faculties;
		}catch (SQLException e) {
			System.out.println(e.getMessage());
			return null;
		}
		
	}
	
	public ArrayList<Event> getEventsOfUniversity(int id){
		String sql = "select * from 'events' where universityid = ?;";
		try {
			Connection con = this.connect();
			PreparedStatement pstmt  = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs  = pstmt.executeQuery();
			ArrayList<Event> events = new ArrayList<>();
			while (rs.next())  {
				events.add(new Event(rs.getInt("id"), rs.getString("name"), rs.getInt("dateinsec"), rs.getString("dateintext")));
			}
			return events;
		}catch (SQLException e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	public ArrayList<Faculty> getFacultiesOfUniversity(int id){
		String sql = "select * from 'faculties' where universityid = ?;";
		try {
			Connection con = this.connect();
			PreparedStatement pstmt  = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs  = pstmt.executeQuery();
			ArrayList<Faculty> faculties = new ArrayList<>();
			while (rs.next())  {
				faculties.add(new Faculty(rs.getInt("id"), rs.getString("name"), rs.getInt("minsum"), rs.getInt("math"), rs.getInt("inf"), rs.getInt("fiz"), rs.getInt("rus")));
			}
			return faculties;
		}catch (SQLException e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	
}
