package com.example.demo;

public class University {
	private String address;
    private String title;
    private int id;
    private int place;
    private String information;

    public University(int id, String address, String title, int place, String information) {
        this.address = address;
        this.id = id;
        this.information = information;
        this.place = place;
        this.title = title;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPlace() {
        return place;
    }

    public void setPlace(int place) {
        this.place = place;
    }

    public String getInformation() {
        return information;
    }

    public void setInformation(String information) {
        this.information = information;
    }

}
