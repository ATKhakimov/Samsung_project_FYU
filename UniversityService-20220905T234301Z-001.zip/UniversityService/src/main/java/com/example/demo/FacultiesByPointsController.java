package com.example.demo;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/facultiesbypoints", produces = "application/json")
public class FacultiesByPointsController {
	private final ServiceDB dbService;
    
    @Autowired
    public FacultiesByPointsController(ServiceDB dbService) {
        this.dbService = dbService;
    }

    @GetMapping(value = "/{points:\\d+}")
    public ArrayList<FacultyWithUniversityName> getCategory(@PathVariable String points) {
        return dbService.getFacultiesByPoints(points);
    }
}
